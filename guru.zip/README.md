VEDYALAY SCHOOL MANAGEMENT SYSTEM 
Submitted In Partial Fulfillment of the Requirement
For the Degree of
Bachelor of Technology
In
Computer Science and Engineering Department
By
VIJAY RANJAN KARN (1702305024)
JATIN KUMAR (1702305009)
MRAGENDRA SONI  (1702705027)
NIKHIL KUMAR (1702305014)

Under the Supervision of
MR. PANKAJ SARASWAT
 
SANSKRITI UNIVERSITY, MATHURA, UTTAR PRADESH-281401
(MAR-2021)

**[Vedyalay School Management School](https://www.vedyalay.com)**
Vedyalay is a School Management System to manage schools and their entities such as classes, sections, students, attendance, exams, teachers, staff, fees, noticeboard will become easier with one such system. It also includes notifications via Email.
It will also help in saving time and effort. The user interface must be user friendly and easy to understand.
The information of the particular student,teacher and staff will be obtained in just one mouse click.   This Management System for all types of educational institutions like schools and colleges. Integrates and facilitates multilevel user accounts of a school.
Super Admin
Admin
Teacher
Staff
Student
Some of the features are as follows:
Security: The data will be more secure because we have different roles & permissions depending on the user.
Performance: The performance of our system is very efficient and easy to  understand.
One-click Access: You will obtain the details of the student, teacher and staff by their name or mobile number just in one click.
