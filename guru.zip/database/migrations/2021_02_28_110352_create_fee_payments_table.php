<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFeePaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fee_payments', function (Blueprint $table) {
            $table->id();
            $table->string('tuition_fee')->nullable();
            $table->string('exam_fee')->nullable();
            $table->string('transport_fee')->nullable();
            $table->string('stationery_fee')->nullable();
            $table->string('sports_fee')->nullable();
            $table->string('club_fee')->nullable();
            $table->string('hostel_fee')->nullable();
            $table->string('laundry_fee')->nullable();
            $table->string('education_tax')->nullable();
            $table->string('eca_fee')->nullable();
            $table->string('late_fine')->nullable();
            $table->string('extra_fee')->nullable();
            $table->string('total_amount')->nullable();
            $table->enum('payment_method',['Bank Transfer','Cash','UPI','Card','Paytm'])->default('Cash');
            $table->string('upi_type')->nullable();
            $table->string('bank_ifsc')->nullable();
            $table->string('bank_accountno')->nullable();
            $table->string('transfer_phone')->nullable();
            $table->string('transfer_date')->nullable();
            $table->string('card_type')->nullable();
            $table->string('remarks')->nullable();
            $table->unsignedBigInteger('student_id')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->unsignedBigInteger('session')->nullable();
            $table->unsignedBigInteger('level_id')->nullable();
            $table->foreign('level_id')->references('id')->on('levels')->onUpdate('CASCADE')->onDelete('RESTRICT');
            $table->foreign('session')->references('id')->on('sessions')->onUpdate('CASCADE')->onDelete('RESTRICT');
            $table->foreign('student_id')->references('id')->on('users')->onUpdate('CASCADE')->onDelete('RESTRICT');
            $table->foreign('created_by')->references('id')->on('users')->onUpdate('CASCADE')->onDelete('RESTRICT');
            $table->foreign('updated_by')->references('id')->on('users')->onUpdate('CASCADE')->onDelete('RESTRICT');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fee_payments');
    }
}
