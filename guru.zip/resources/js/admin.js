global.$ = global.jQuery = require('jquery');
require('bootstrap');
require('../template/admin/assets/plugins/select2/dist/js/select2.full.min.js');
require('../template/admin/assets/js/adminlte.js');
// require('../template/admin/assets/plugins/moment/moment.js');
require('../template/admin/assets/plugins/daterangepicker/daterangepicker.js');