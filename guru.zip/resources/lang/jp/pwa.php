<?php

// JAPANESE

return [
    'title'         => 'pwa',
    'update'        => '更新',
    'choose-image'  => '画像を選択',
    'change-icon'   => 'アイコンを変更',
    'change-splash' => 'スプラッシュを変更する',
];
