<?php

// ARABIC

return [
    'title'         => 'وزن',
    'update'        => 'تحديث',
    'choose-image'  => 'اختر صورة',
    'change-icon'   => 'تغيير الايقونة',
    'change-splash' => 'تغيير البداية',
];
