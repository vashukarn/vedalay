<?php

// ENGLISH

return [
    'title'         => 'PWA',
    'update'        => 'Update',
    'choose-image'  => 'Choose Image',
    'change-icon'   => 'Change Icon',
    'change-splash' => 'Change Splash',
];
