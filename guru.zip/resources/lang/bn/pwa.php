<?php

// BANGLA

return [
    'title'         => 'PWA',
    'update'        => 'হালনাগাদ',
    'choose-image'  => 'চিত্র চয়ন করুন',
    'change-icon'   => 'প্রতীক পাল্টান',
    'change-splash' => 'স্প্ল্যাশ পরিবর্তন করুন',
];
