<?php

// CHINESE

return [
    'title'         => '改變飛濺',
    'update'        => '更新資料',
    'choose-image'  => '選擇圖片',
    'change-icon'   => '變更圖示',
    'change-splash' => '改變飛濺',
];
