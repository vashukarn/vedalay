<?php

return [
    'base_domain'			        => 'localhost',
    'prefix'                => '/pwa',
    'icons_path'			         => storage_path('/../vendor/codexshaper/laravel-pwa/resources/icons'),
    'scope'					            => '.',
];
