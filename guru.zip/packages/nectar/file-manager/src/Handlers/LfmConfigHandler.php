<?php

namespace App\Handlers;

class LfmConfigHandler extends \Mafftor\LaravelFileManager\Handlers\ConfigHandler
{
    public function userField()
    {
        return parent::userField();
    }
}
