<?php

namespace Mafftor\LaravelFileManager\Events;

class ImageWasResized
{
    private $path;

    public function __construct($path)
    {
        $this->path = $path;
    }

    /**
     * @return string
     */
    public function path()
    {
        return $this->path;
    }
}
