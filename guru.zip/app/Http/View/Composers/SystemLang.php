<?php
namespace App\Http\View\Composers;

use App\Models\AppSetting;
use Illuminate\View\View;

class SystemLang
{
    public function compose(View $view)
    {
        
    }
}
